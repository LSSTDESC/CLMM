"""@file _ccl_supported_versions.py
Versions of CCL supported by the current CLMM version
"""
VMIN = "2.7.1.dev10+gf81b59a4"
VMAX = "3"
