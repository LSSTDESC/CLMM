"""@file __init__.py
Cosmology package
"""
